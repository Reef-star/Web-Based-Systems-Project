<!--Danah Alharbi-->
<?php 
    session_start();
    require("include/connection.php");
    // an array to store past purchased product details
    $past_purchases = [];
    // Check if the 'cart' cookie exists and is an array
    if (isset($_COOKIE['cart']) && is_array($_COOKIE['cart'])) {
        // Loop through each product ID and quantity stored in the cart cookie, im just going to use the pid to query the database
        foreach ($_COOKIE['cart'] as $pid => $qty) {
            
            $query = "SELECT ProductID, Name, Image, Price, AnimalType FROM Product WHERE ProductID = '$pid'";
            $result = mysqli_query($_SESSION['connection'], $query);
            if ($row = mysqli_fetch_assoc($result)) {
                 
                $past_purchases[] = $row;
            }
        }
    }
    $animal=array("Cat","Dog","Bird");
    $product=array("Food","Toy");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="Pet Shop, Pets Heaven, Cats, Dogs, Birds, Pet Food, Pet Toys, Animal Supplies, Online Pet Store">
    <meta name="description" content="Welcome to Pets Heaven, your online pet shop offering a wide range of pet products for cats, dogs, and birds. Shop our collection of pet food, toys, and accessories with ease.">

    <title>Home Page - Pets Heaven</title>
    <link rel="stylesheet" type="text/css" href="CSS/header%20and%20menu%20bar.css">
    <link rel="stylesheet" type="text/css" href="CSS/products%20display%20C&amp;A%20home.css">
    
</head>
<body>
    <div class="header">Pets Heaven</div> <!--Shop's name-->
    <!--start menu bar-->
    <div class="navbar">
        <!--start drop-down menus-->
        <ul class="nav-links"> 
            
            <?php //this function will eliminate the repetetion in the menu bar 
                foreach($animal as $value){
                    echo "<li>";
                    echo "<a href=#$value>$value</a>";
                    echo "<div class='dropdown'>";
                    foreach($product as $pro){
                       echo  "<a href=#$value-$pro>$pro</a>";  
                    }
                    echo "</div>";
                    echo "</li>";
                }
            ?>
            
            <li><a href="#previous-purchases">Previous Purchases</a></li>
            <li><a href="HTML/contact us page.php">Contact Us</a></li>
            <li><a href="HTML/admin%20authentication%20page.php">Admin</a></li>
        </ul>
        <!--end drop-down menu-->
        
        <!--display total num of items and price-->
        <?php echo "<div class='cart'> ";
                    echo '<a href="HTML/cart page.php" class="cart-icon">🛒</a>';
         include("include/cartSummary.php"); 
        echo "</div>";?>
        
        <!--end cart-->
        </div>
        <!--end menu bar-->
        
        <?php //using for loop and a function to display products
            foreach($animal as $anim){
                echo "<h1 id='$anim' class='animal-name'>$anim</h1>";

                foreach($product as $pro){
                    echo "<h2 id='$anim-$pro' class='product-type'>$pro</h2>";
                    productQuery($anim,$pro); 
                }
            }
    ?>
        
        
        <!--start previous purchases section-->

<?php
    // Display previously purchased products stored in the user's cookie
    // Each product is shown with its image, name, price, and a "View Product" button
    if (!empty($past_purchases)) {
        echo "<h1 id='previous-purchases' class='animal-name'>Previous Purchases</h1>";
        echo "<div class='products'>";
        // Loop through each product ID retrieved from cookies and show product details
        foreach ($past_purchases as $row) {
            $name = $row['Name'];
            $price = $row['Price'];
            $image = $row['Image'];
            $animal = $row['AnimalType'];
            $pid = $row['ProductID'];

            echo "<div class='product'>";
            echo "<img src='Images/$image' alt='$name'>";
            echo "<p>$name</p>";
            echo "<p>SAR $price</p>";
            echo "<a href='HTML/products%20details%20page.php?pid=".$pid."'><button class='add-to-cart'>View Product</button></a>";
            echo "</div>";
        }

        echo "</div>";
    }
?>

        <!--end previous purchases section-->
</body>
</html>
<?php 

    function productQuery($animal,$product){
        
        if (isset($_SESSION["connection"])) {
        
        $query = "SELECT ProductID, Name, Image, Price FROM Product WHERE AnimalType = '$animal' AND ProductType = '$product'";
        $result = mysqli_query($_SESSION["connection"], $query);
        
        if (mysqli_num_rows($result) > 0) {
            echo "<div class='products'>";
            
            while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {//this loop will go through all the products in the database based on the spicified condition in the query
        
                echo "<div class='product'>";
                echo "<img src='Images/". $row['Image'] . "' alt='" . $row['Name'] . "'>";
                echo "<p>" . $row['Name'] . "</p>";
                echo "<p>SAR " . $row['Price'] . "</p>";
                echo "<a href='HTML/products%20details%20page.php?pid=".$row['ProductID']."'><button class='add-to-cart'>View Product</button></a>";
                echo "</div>"; 
            }
            echo "</div>";
        }
    }
    }
 require("include/close connection.php");?>