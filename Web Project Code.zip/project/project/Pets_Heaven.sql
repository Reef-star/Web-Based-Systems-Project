-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 04, 2025 at 09:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Pets Heaven`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'Shahad', 'password123'),
(2, 'Danah', 'securepass456'),
(3, 'Darah', 'mypassword789'),
(4, 'Raghad', '123pass'),
(5, 'Albandari', 'my4567password'),
(6, 'Donia', '987654321'),
(7, 'Reef', 'password987');

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `ProductID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `AnimalType` varchar(100) NOT NULL,
  `ProductType` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`ProductID`, `Name`, `AnimalType`, `ProductType`, `Price`, `Stock`, `Description`, `Image`) VALUES
(1, 'Kit Kat Dry Food - Salmon Flavor', 'Cat', 'Food', 45.00, 10, 'Nutritious salmon-flavored dry food for cats', 'cat-food1.png'),
(2, 'Kit Kat Dry Food - Mini Fish Medley Flavor', 'Cat', 'Food', 49.50, 10, 'Mini fish medley-flavored dry food for cats', 'cat-food4.png'),
(3, 'Kit Kat Dry Food - Chicken Cuisine Flavor', 'Cat', 'Food', 40.00, 10, 'Chicken cuisine-flavored dry food for cats', 'cat-food5.png'),
(4, '3 Colorful Cat Balls', 'Cat', 'Toy', 10.00, 3, 'Set of 3 colorful balls for cats to play with', 'cat-toy1.png'),
(5, 'Cat Toy Rod', 'Cat', 'Toy', 15.00, 15, 'Interactive toy rod for cats', 'cat-toy3.png'),
(6, 'Josi Dog Dry Food For Active Adult Dogs', 'Dog', 'Food', 150.00, 10, 'High-energy dry food for active dogs', 'dog-food1.png'),
(8, 'Rope Toy', 'Dog', 'Toy', 10.60, 15, 'Durable rope toy for dogs', 'dog-toy1.png'),
(9, 'Prestige Parrot Seeds', 'bird', 'Food', 82.00, 10, 'this product is now updated', 'bird-food1.png'),
(10, 'Vadigran Parrot Seeds', 'Bird', 'Food', 38.00, 6, 'Premium Vadigran seed mix for parrots', 'bird-food2.png'),
(11, 'Bird Chewing Toy', 'Bird', 'Toy', 5.00, 15, 'Chewing toy for birds', 'bird-toy1.png'),
(12, 'danah added this', 'Dog', 'Toy', 12.00, 14, 'danah added this', 'cat-food3.png'),
(14, 'wet food', 'Cat', 'Food', 3.00, 21, 'meow', 'cat-food2.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`ProductID`),
  ADD UNIQUE KEY `Name` (`Name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Product`
--
ALTER TABLE `Product`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
