<!--Danah Alharbi-->
<html><body>
<?php 
    
    $db_link= mysqli_connect("localhost","root","","Pets Heaven","3307");
if(!$db_link)
    die("Couldn't connect to the database</p></body></html>");
$_SESSION["connection"]=$db_link;

//this code will be used to connect to the database
?> 
    </body></html>