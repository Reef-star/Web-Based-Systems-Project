<!--Danah Alharbi-->
<html><body>
<?php
    
   if (isset($_SESSION["connection"])) {
        mysqli_close($_SESSION["connection"]);
        unset($_SESSION["connection"]);
       //this code will close the database connection
?> 
    </body></html>