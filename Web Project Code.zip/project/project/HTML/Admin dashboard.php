<!--Reef-->
<?php
session_start();

//  Handle logout when user clicks the logout link
if (isset($_GET['logout'])) {
    unset($_SESSION['is_manager']);   // Remove login session
    session_destroy();                // Fully destroy session
    header("Location: admin authentication page.php"); // Redirect to login
    exit();
}

// Block access if user is not logged in
if (!isset($_SESSION['is_manager'])) {
    header("Location: admin authentication page.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Admin interface for managing pet supplies, including inventory and order processing. Streamline your pet shop operations with easy navigation and efficient tools.">
    <meta name="keywords" content="admin interface, pet supplies management, inventory control, order processing, pet shop admin, online pet store management">
    <title>Admin Home Page - Pets Heaven</title>
    <link rel="stylesheet" href="../CSS/admin_dashboard.css">
</head>
<body>
    <!-- Header -->
    <div class="header">Pets Heaven</div>
    
    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <div class="button-container">
            <a href="Add%20product%20page.php">Add Product</a>
            <a href="modify%20and%20delete%20product.php">Modify or Delete</a>
            <a href="?logout=1" class="logout-button">Log Out</a>
        </div>
    </div>
</body>
</html>
