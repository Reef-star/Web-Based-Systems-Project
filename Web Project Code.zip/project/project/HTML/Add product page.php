<!-- Donia -->
<?php

session_start();
include("../include/connection.php");

if (!isset($_SESSION['is_manager'])) {
    header("Location: admin authentication page.php");
    exit();
}

$successMessage = "";
$errors = [];
$name = $animal_type = $product_type = $price = $stock = $description = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $animal_type = trim($_POST['animalType']);
    $product_type = trim($_POST['category']);
    $price = trim($_POST['price']);
    $stock = trim($_POST['stock']);
    $description = trim($_POST['description']);

    // Check for empty fields
    if (empty($name) || empty($animal_type) || empty($product_type) || empty($price) || empty($stock) || empty($description)) {
        $errors[] = "Please fill in all fields.";
    }

    // Check for valid numeric values
    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Price must be a non-negative number.";
    }

    if (!is_numeric($stock) || $stock < 0) {
        $errors[] = "Stock must be a non-negative number.";
    }

    // Check for duplicate name
    $checkQuery = "SELECT * FROM Product WHERE Name = '" . mysqli_real_escape_string($_SESSION["connection"], $name) . "'";
    $checkResult = mysqli_query($_SESSION["connection"], $checkQuery);
    if (mysqli_num_rows($checkResult) > 0) {
        $errors[] = "A product with this name already exists.";
    }

    // Upload image and move it to Images folder
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['image']['tmp_name'];
        $fileName = basename($_FILES['image']['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExt = ['jpg', 'jpeg', 'png'];

        if (!in_array($fileExt, $allowedExt)) {
            $errors[] = "Only JPG, JPEG, or PNG files are allowed.";
        } else {
            $targetDir = "../Images/";
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $targetFile = $targetDir . $fileName;
            
        }
    } else {
        $errors[] = "Image is required.";
    }

    if (empty($errors)) {
        $query = "INSERT INTO Product (Name, AnimalType, ProductType, Price, Stock, Description, Image)
                  VALUES ('$name', '$animal_type', '$product_type', '$price', '$stock', '$description', '$fileName')";
        $result = mysqli_query($_SESSION["connection"], $query);

        if ($result && isset($fileTmp) && !file_exists($targetFile)) {
            move_uploaded_file($fileTmp, $targetFile);
        }

        if ($result) {
            $successMessage = "Product added successfully!";
            $name = $animal_type = $product_type = $price = $stock = $description = ""; // reset fields
        } else {
            $errors[] = "Database error: " . mysqli_error($_SESSION['connection']);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Add Product - Pets Heaven</title>
  <link rel="stylesheet" href="../css/add%20and%20modify%20page.css" />
  <style>
    .success-message {
        color: green;
        font-weight: bold;
        margin: 10px 0;
    }
    .error-message {
        color: red;
        font-weight: bold;
        margin: 5px 0;
    }
  </style>
  <script>
    function validateForm() {
      var form = document.forms["productForm"];
      var fields = ["name", "animalType", "category", "price", "stock", "description", "image"];
      for (var i = 0; i < fields.length; i++) {
        if (!form[fields[i]].value.trim()) {
          alert("Please fill in all fields.");
          return false;
        }
      }
      return true;
    }

    function validateNumberField(id, label) {
      const field = document.getElementById(id);
      const value = field.value.trim();
      if (value === "") return;

     if (isNaN(value) || Number(value) < 0 || /[A-Za-z]/.test(value)) {
    alert(label + " must be a valid non-negative number.");
    field.value = "";
    field.focus();
}}


    window.addEventListener("load", function () {
      document.getElementById("price").addEventListener("blur", () => validateNumberField("price", "Price"));
      document.getElementById("stock").addEventListener("blur", () => validateNumberField("stock", "Stock"));
    });
  </script>
</head>
<body>
  <div class="header">Pets Heaven</div>
  <div class="container">
    <div class="form-container">
      <div class="back-button-container">
        <a href="Admin%20dashboard.php" class="back-to-home-button">Back to Home Page</a>
      </div>
      <div class="page-title">Add a Product</div>

      <form name="productForm" method="POST" enctype="multipart/form-data" onsubmit="return validateForm();">
        <p><label>Name:</label></p>
        <p><input type="text" name="name" placeholder="Enter product name" value="<?= htmlspecialchars($name) ?>" /></p>

        <p><label>Animal Type:</label></p>
        <p>
          <select name="animalType">
            <option value="" disabled <?= $animal_type === '' ? 'selected' : '' ?>>Select Animal Type</option>
            <option value="Dog" <?= $animal_type === 'Dog' ? 'selected' : '' ?>>Dog</option>
            <option value="Cat" <?= $animal_type === 'Cat' ? 'selected' : '' ?>>Cat</option>
            <option value="Bird" <?= $animal_type === 'Bird' ? 'selected' : '' ?>>Bird</option>
          </select>
        </p>

        <p><label>Product Type:</label></p>
        <p>
          <select name="category">
            <option value="" disabled <?= $product_type === '' ? 'selected' : '' ?>>Select Product Type</option>
            <option value="Food" <?= $product_type === 'Food' ? 'selected' : '' ?>>Food</option>
            <option value="Toy" <?= $product_type === 'Toy' ? 'selected' : '' ?>>Toy</option>
          </select>
        </p>

        <p><label>Price:</label></p>
        <p><input type="number" id="price" name="price" min=0.0 step="0.01" placeholder="Enter price" value="<?= htmlspecialchars($price) ?>" />  </p>

        <p><label>Stock Available:</label></p>
        <p><input type="number" id="stock" name="stock" min=0.0 placeholder="Enter stock quantity" value="<?= htmlspecialchars($stock) ?>" /></p>

        <p><label>Description:</label></p>
        <p><textarea name="description" placeholder="Enter product description"><?= htmlspecialchars($description) ?></textarea></p>

        <p><label>Image:</label></p>
        <p><input type="file" name="image" accept="image/*" /></p>

        <?php
        if (!empty($successMessage)) {
            echo "<div class='success-message'>$successMessage</div>";
        }
        if (!empty($errors)) {
            foreach ($errors as $err) {
                echo "<div class='error-message'>$err</div>";
            }
        }
        ?>

        <div class="button-container clearfix">
          <input type="reset" class="clear-button" value="Clear" onclick="window.location.href = window.location.href;" />
          <input type="submit" class="submit-button" value="Submit" />
        </div>
      </form>
    </div>
  </div>
</body>
</html>
<?php require("../include/close connection.php"); ?>
